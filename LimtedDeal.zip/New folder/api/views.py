from django.shortcuts import render
import json
# Create your views here.
from django_filters.rest_framework import FilterSet
from rest_framework import viewsets, serializers, status
from rest_framework.response import Response
from rest_framework.views import APIView

from api.models import *


class SampleSerializer(serializers.ModelSerializer):
    class Meta:
        model = SampleModel
        fields = '__all__'


class SampleViewSets(viewsets.ModelViewSet):
    serializer_class = SampleSerializer

'''
        APIVIew for initializing a new deal by the retailer
        METHODS: GET,POST
'''


class DealCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Deals
        fields = '__all__'



class DealInitiate(viewsets.ModelViewSet):
    serializer_class = DealCreateSerializer
    queryset = Deals.objects.all()

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        if serializer.data:
            deal_request_data ={'deal': serializer.data['id'],
                                'live_count': serializer.data['quantity']
                                }
            DealTracker.objects.create(**deal_request_data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    # def update(self, request, *args, **kwargs):




class ProductsCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Products
        fields = '__all__'


class CreateItemViewSet(viewsets.ModelViewSet):
    serializer_class = ProductsCreateSerializer
    queryset = Products.objects.all()


class RetailCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Retailer
        fields = '__all__'


class RetailCreateViewSet(viewsets.ModelViewSet):
    serializer_class = RetailCreateSerializer
    queryset = Retailer.objects.all()


class ClaimDealSerializer(serializers.ModelSerializer):

    class Meta:
        model = DealTracker
        fields = ['deal','live_count']

    # def update(self, instance, validated_data):

# APIView

class ClaimDealView(APIView):
    def post(self, request):
        response = {}
        try:
            data = request.data.get('body')
            deal_obj = Deals.objects.filter(pk=data['deal']).first()
            deal_validated = self.validate_deal(deal_obj)
            if deal_validated:
                deal_tracker_obj = DealTracker.objects.filter(deal=deal_obj).first()
                if deal_tracker_obj.live_count > 0:
                    if deal_tracker_obj.customers:
                        customer_list = deal_tracker_obj.customer
                        cust_deal_list = customer_list['customer']
                        if request.data.get('customer') not  in cust_deal_list:
                            cust_deal_list.append(request.data['customer'])
                        else:
                            return Response(data={}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        customer_list = dict()
                        customer_list['customer'] = [
                            request.data['customer']
                        ]
                    deal_tracker_obj.customers = customer_list
                    deal_tracker_obj.save()
            response = Response(data=None, headers={}, status=status.HTTP_201_CREATED)

        except Exception as ex:
            print(str(ex))
        return response


    def validate_deal(self, deal_obj):
        if deal_obj and deal_obj.active and datetime.now() < deal_obj.end_validity and deal_obj.quantity > 0:
            return True
        else:
            return False