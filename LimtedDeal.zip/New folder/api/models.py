from django.db import models
from datetime import datetime
# Create your models here.


class SampleModel(models.Model):
    name = models.CharField(max_length=100)

    class Meta:
        app_label = 'api'
        verbose_name_plural = 'SampleModel'


class Retailer(models.Model):
    name = models.CharField(max_length=255)
    address = models.TextField()

    class Meta:
        app_label = 'api'
        verbose_name_plural = 'Retailer'


class Products(models.Model):
    item_name = models.CharField(max_length=255)
    brand = models.ForeignKey(Retailer, on_delete=models.CASCADE)

    class Meta:
        app_label = 'api'
        verbose_name_plural = 'Product'


class Deals(models.Model):
    start_validity = models.DateTimeField(default=datetime.utcnow())
    quantity = models.IntegerField(default=0)
    item = models.ForeignKey(Products, on_delete=models.CASCADE)
    active = models.BooleanField(default=False)
    retailer = models.ForeignKey(Retailer, on_delete=models.CASCADE, null=True)
    deal_name = models.CharField(max_length=155, null=True, blank=False)
    end_validity = models.DateTimeField(default=datetime.utcnow())

    class Meta:
        app_label = 'api'
        verbose_name_plural = 'Deals'


class Customer(models.Model):
    name = models.CharField(max_length=100)

    class Meta:
        app_label = 'api'
        verbose_name_plural = 'Customer'


class DealTracker(models.Model):

    deal = models.ForeignKey(Deals, on_delete=models.CASCADE, unique=True)
    customers = models.JSONField()
    live_count = models.IntegerField(default=0)

    class Meta:
        app_label = 'api'
        verbose_name_plural = 'Deal Tracker'


