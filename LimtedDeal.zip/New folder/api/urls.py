from django.urls import path
from rest_framework import routers

from api.views import *

router = routers.DefaultRouter()
router.register(r'test', SampleViewSets, basename='test')


router.register(r'deal', DealInitiate, basename='deal')
router.register(r'product', CreateItemViewSet, basename='product')
router.register(r'retailer', RetailCreateViewSet, basename='retailer')

nested_urlpatterns = [
    path('claim-deal', ClaimDealView.as_view(), name='claim')
]

# router.register(r'test', SampleViewSets, basename='test')

